package com.java.LuXingyu;

/**
 * Created by Angel on 2016/8/17.
 */
public interface OnTouchUpListener {

    void OnRefreshing();
    void OnLoading();

}
