package com.java.LuXingyu;

public class Constant {
    public static int w,h;
}
