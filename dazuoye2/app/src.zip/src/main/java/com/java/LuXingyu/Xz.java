package com.java.LuXingyu;

public class Xz {
    public String name;
    public String work;
    public String school;
    public String ID;

    public Xz() {

    }
    public Xz(String name, String work, String school) {
        this.name = name;
        this.work = work;
        this.school = school;
    }



}
