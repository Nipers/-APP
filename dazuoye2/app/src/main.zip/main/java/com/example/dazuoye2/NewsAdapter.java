package com.example.dazuoye2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    //点击
    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }
    private OnItemClickListener mOnItemClickListener;
    public void setOnItemClickListener(OnItemClickListener mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }


    private List<News> myNewsList;
    private Context context;

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView from;
        TextView date;

        public ViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.text_title);
            from = (TextView) view.findViewById(R.id.text_from);
            date = (TextView) view.findViewById(R.id.text_date);
        }
    }


    public NewsAdapter(List<News> newsList) {
        myNewsList = newsList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_news, parent, false);
            ViewHolder holder = new ViewHolder(view);
            return holder;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof ViewHolder) {
            News news = myNewsList.get(myNewsList.size()-1-position);
            ((ViewHolder)holder).title.setText(news.getTitle());
            ((ViewHolder)holder).from.setText(news.getFrom());
            ((ViewHolder)holder).date.setText(news.getDate());
        }

        if(mOnItemClickListener != null){
            //为ItemView设置监听器
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = holder.getLayoutPosition(); // 1
                    mOnItemClickListener.onItemClick(holder.itemView,position); // 2
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return myNewsList.size();
    }


}