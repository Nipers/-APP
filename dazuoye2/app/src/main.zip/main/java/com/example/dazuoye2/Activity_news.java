package com.example.dazuoye2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

public class Activity_news extends AppCompatActivity {
    private ImageButton button;
    private LinearLayout L_star,L_share;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        button=(ImageButton)findViewById(R.id.button_news_back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        L_star=(LinearLayout)findViewById(R.id.star);
        L_share=(LinearLayout)findViewById(R.id.share);
        L_star.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Activity_news.this, "已收藏", Toast.LENGTH_SHORT).show();
            }
        });
        L_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(Activity_news.this, L_share);
                popup.getMenu().add(0,1,0,"微信").setIcon(R.mipmap.icon_wechat);
                popup.getMenu().add(0,2,0,"微博").setIcon(R.mipmap.icon_sina);

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        if(item.getItemId()==1)
                            Toast.makeText(Activity_news.this, "wechat", Toast.LENGTH_SHORT).show();
                        if(item.getItemId()==2)
                            Toast.makeText(Activity_news.this, "weibo", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });
                popup.show(); //showing popup menu
            }
        });
    }
}