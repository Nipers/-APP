package com.example.dazuoye2;

public class News {

    private String title;
    private String from;
    private String date;

    public News(String title, String from, String date) {
        this.title = title;
        this.from = from;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public String getFrom() {
        return from;
    }

    public String getDate() {
        return date;
    }
}

