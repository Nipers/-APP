package com.example.dazuoye2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

public class Activity_main extends AppCompatActivity {
    private ViewPager2 viewPager2;
    private TabLayout tabs;
    private ArrayList<Fragment> fragments;
    private TabLayoutMediator mediator;
    private ImageButton button_wode,button_search,button_fenlei;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager2 = findViewById(R.id.viewpager2);

        tabs=findViewById(R.id.tabs);
        final String[] tabs_name = new String[]{"要闻", "数据", "图谱","聚类","学者"};

        button_wode=(ImageButton)findViewById(R.id.button_wode);
        button_wode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(Activity_main.this, Activity_my.class);
                startActivity(intent);
                overridePendingTransition(0,0);
            }
        });

        button_search=(ImageButton)findViewById(R.id.button_search);
        button_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(Activity_main.this, Activity_search.class);
                startActivity(intent);
            }
        });

        button_fenlei=(ImageButton)findViewById(R.id.button_fenlei);
        button_fenlei.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(Activity_main.this, Activity_fenlei.class);
                startActivity(intent);
            }
        });

        final Fragment f_yw=Fragment_yw.newInstance("1","1");

        //禁用预加载
        viewPager2.setOffscreenPageLimit(ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT);
        //Adapter
        viewPager2.setAdapter(new FragmentStateAdapter(getSupportFragmentManager(), getLifecycle()) {

            @NonNull
            @Override

            public Fragment createFragment(int position) {
                if(position==0)//要闻
                    return f_yw;
                else if(position==1)//数据
                    return Fragment_sj.newInstance("1","2");
                else if(position==2)//图谱
                    return Fragment_tp.newInstance("1","2");
                else if(position==3)//聚类
                    return Fragment_jl.newInstance("1","2");
                else//学者
                    return Fragment_xz.newInstance("1","1");
            }

            @Override
            public int getItemCount() {
                return tabs_name.length;
            }
        });
        //viewPager 页面切换监听
        viewPager2.registerOnPageChangeCallback(changeCallback);
        mediator = new TabLayoutMediator(tabs, viewPager2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                //这里可以自定义TabView
                TextView tabView = new TextView(Activity_main.this);
                tabView.setGravity(Gravity.CENTER);
                tabView.setText(tabs_name[position]);
                tab.setCustomView(tabView);

            }
        });
        //要执行这一句才是真正将两者绑定起来
        mediator.attach();
    }
    private ViewPager2.OnPageChangeCallback changeCallback;{
        changeCallback = new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                //可以来设置选中时tab的大小
                int tabCount = tabs.getTabCount();
                for (int i = 0; i < tabCount; i++) {
                    TabLayout.Tab tab = tabs.getTabAt(i);
                    assert tab != null;
                    TextView tabView = (TextView) tab.getCustomView();
                    if(i==position){
                        tabView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    } else{
                        tabView.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
                    }
                }
            }
        };
    }

    @Override
    protected void onDestroy() {
        mediator.detach();
        viewPager2.unregisterOnPageChangeCallback(changeCallback);
        super.onDestroy();
    }

}

