package com.example.dazuoye2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Activity_search extends AppCompatActivity {
    private TextView t1,t2,t3,t4,t5;
    private String s1,s2,s3,s4,s5;
    private ImageButton button;
    private Button button_begin_search;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        t1=(TextView)findViewById(R.id.search_1);
        t2=(TextView)findViewById(R.id.search_2);
        t3=(TextView)findViewById(R.id.search_3);
        t4=(TextView)findViewById(R.id.search_4);
        t5=(TextView)findViewById(R.id.search_5);
        button=(ImageButton)findViewById(R.id.button_search_back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        searchView=(SearchView)findViewById(R.id.search_view);
        searchView.setSubmitButtonEnabled(true);
        // 设置搜索文本监听
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            // 当搜索内容改变时触发该方法
            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText))
                    return false;
                //do something
                return false;

            }
            public boolean onQueryTextSubmit(String query) {
                s5=s4;
                s4=s3;
                s3=s2;
                s2=s1;
                s1=query;
                t1.setText(s1);
                t2.setText(s2);
                t3.setText(s3);
                t4.setText(s4);
                t5.setText(s5);
                // 实际应用中应该在该方法内执行实际查询
                return false;
            }
        });
    }
}