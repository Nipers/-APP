package com.example.dazuoye2;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Fragment_yw extends Fragment implements OnTouchUpListener{

    private PullLoadRecyclerViewLayout mLayout;
    private List<News> newsList = new ArrayList<>();
    private NewsAdapter newsAdapter;
    private View rootView;
    private View mHeaderView;
    private View mFooterView;

    private static final String ARG_PARAM1 = "title";
    private static final String ARG_PARAM2 = "from";
    private static final String ARG_PARAM3 = "date";

    private String title;
    private String from;
    private String date;

    public Fragment_yw() {
        // Required empty public constructor
    }

    public static Fragment_yw newInstance(String a,String b) {
        Fragment_yw fragment = new Fragment_yw();
        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, title);
//        args.putString(ARG_PARAM2, from);
//        args.putString(ARG_PARAM3, date);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            title = getArguments().getString(ARG_PARAM1);
            from = getArguments().getString(ARG_PARAM2);
            date = getArguments().getString(ARG_PARAM3);
        }
        initNews();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        newsAdapter=new NewsAdapter(newsList);
        rootView=inflater.inflate(R.layout.fragment_yw, container, false);
        LayoutInflater my_inflater = LayoutInflater.from(getActivity());
        mHeaderView = my_inflater.inflate(R.layout.co_refresh_header, null);
        mFooterView = my_inflater.inflate(R.layout.co_refresh_footer, null);
        mLayout = (PullLoadRecyclerViewLayout)rootView.findViewById(R.id.pull_load_layout);
        mLayout.addFooterView(mFooterView, DisplayUtil.dpToPx(getActivity(), 40));
        mLayout.addHeaderView(mHeaderView, DisplayUtil.dpToPx(getActivity(), 60));
        mLayout.setMyRecyclerView(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false),
                newsAdapter, true);
        mLayout.addOnTouchUpListener(this);

        newsAdapter.setOnItemClickListener(new NewsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent=new Intent();
                intent.setClass(getActivity(), Activity_news.class);
                startActivity(intent);
            }
        });
        return rootView;
    }


    private void initNews(){
        if(newsList.isEmpty())
            for(int i=0;i<10;i++){
                News n=new News("标题","二流报纸","2020-09-01");
                newsList.add(n);
            }
    }

    private void onDataRefreshing() {
        //增加新闻
        newsList.add(new News("刷新的新闻","2","3"));
        //更新adapter
        newsAdapter.notifyDataSetChanged();
        //停止更新动作
        onRefreshFinish(true);
    }

    private void onDataLoadingMore() {
        //增加新闻
        newsList.add(0,new News("加载的新闻","2","3"));
        //更新adapter
        newsAdapter.notifyDataSetChanged();
        //更新之后滑到最底端
        mLayout.setRecyclerViewScrollToPosition(newsAdapter.getItemCount()-1);
        //停止更新动作
        onLoadMoreFinish(true);
    }

    @Override
    public void OnRefreshing() {
        mLayout.setHeaderState(PullLoadRecyclerViewLayout.HEADER_STATE_REFRESHING);
        onDataRefreshing();
    }

    @Override
    public void OnLoading() {
        mLayout.setFooterState(PullLoadRecyclerViewLayout.FOOTER_STATE_LOADING);
        onDataLoadingMore();
    }

    private void onRefreshFinish(final boolean success) {
        new Handler() {
            @Override
            public void handleMessage(Message message) {
                mLayout.setHeaderState(success ? PullLoadRecyclerViewLayout.HEADER_STATE_COMPLETE :
                        PullLoadRecyclerViewLayout.HEADER_STATE_FAIL);
            }
        }.sendEmptyMessageDelayed(0, 100);
    }

    private void onLoadMoreFinish(final boolean success) {
        new Handler() {
            @Override
            public void handleMessage(Message message) {
                mLayout.setFooterState(success ? PullLoadRecyclerViewLayout.FOOTER_STATE_COMPLETE :
                        PullLoadRecyclerViewLayout.FOOTER_STATE_FAIL);
            }
        }.sendEmptyMessageDelayed(0, 100);
    }




}